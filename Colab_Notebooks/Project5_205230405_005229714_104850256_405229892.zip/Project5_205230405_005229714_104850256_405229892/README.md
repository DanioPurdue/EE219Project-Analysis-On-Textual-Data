# EE219 Project 5

## Group Members

Jianxiong Wang: 205230405 

Yijun Wu: 005229714 

Yutong Sun: 104850256 

Yanzhao Wang: 405229892

## How to Run the Code

Before running each problem's code, you need to run `RewriteDataFile.ipynb` to generate a new set of json files that do not contain any extraneous information, and this would speed up the loading time.  

## Files

```
EE219Project5_Report_Q1_Q14.ipynb	
Problem1_6.py
Problem10.py				
Problem7.py
Problem11_13.py				
Problem8_9.py
Problem14.py				
Questtion15_16.ipynb
RewriteDataFile.ipynb
```

