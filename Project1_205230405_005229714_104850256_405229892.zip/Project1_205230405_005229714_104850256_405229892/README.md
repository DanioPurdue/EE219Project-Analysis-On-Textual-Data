# ECE-219 Project 1

## Group Members

Jianxiong Wang: 205230405 

Yijun Wu: 005229714 

Yutong Sun: 104850256 

Yanzhao Wang: 405229892



## `EE219Project1.ipynb`
To run our code, simply open it in jupyter notebook and "run all", you may have to do:

```python
import nltk
nltk.download()
```

to download the nltk pakage.

Question 7 takes hours to run, so it is strongly recommended not to run the code since all the output has already been displayed.

## Dependencies
These dependencies are in the `requiremens.txt` file.

To install them, please run

`pip install -r requirements.txt`