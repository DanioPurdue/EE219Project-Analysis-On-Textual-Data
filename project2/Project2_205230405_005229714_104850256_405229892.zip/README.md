# ECE219 Project2 Clustering
Install the following:
```
$ pip install nltk scikit-learn
$ python -m nltk.downloader all
$ pip install plotly
```

Run:
```
$ jupyter notebook
Open Project2.ipynb and click Cell -> Run All
```

** Please use Python 3 **
