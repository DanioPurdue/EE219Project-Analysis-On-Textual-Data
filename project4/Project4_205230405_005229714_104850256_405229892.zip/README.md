# ECE-219 Project 4

## Group Members

Jianxiong Wang: 205230405 

Yijun Wu: 005229714 

Yutong Sun: 104850256 

Yanzhao Wang: 405229892



## codes are in `EE219Project4_part1.ipynb` and `EE219Project4_part2_part3.ipynb`
To run our code, simply open it in jupyter notebook and "run all"

## Dependencies
These dependencies are in the `requiremens.txt` file.

To install them, please run

`pip install -r requirements.txt`

