# ECE-219 Project 3

## Group Members

Jianxiong Wang: 205230405 

Yijun Wu: 005229714 

Yutong Sun: 104850256 

Yanzhao Wang: 405229892



## `EE219Project1.ipynb`
To run our code, simply open it in jupyter notebook and "run all"

## Dependencies
These dependencies are in the `requiremens.txt` file.

To install them, please run

`pip install -r requirements.txt`

